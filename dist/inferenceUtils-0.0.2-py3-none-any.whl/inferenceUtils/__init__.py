from inferenceUtils.utilsFunction import Utils

__version__ = "0.0.2"
